# Travel Lab Academy - GitHub Upload Bundle

Upload these files to your GitHub repo so Vercel deploys them.

## 📁 File mapping (where each file goes in your repo)

```
your-repo/
├── index.html                      ← REPLACE with the index.html in this folder
├── api/
│   ├── create-checkout-session.js  ← REPLACE (fixes the productKey bug)
│   ├── webhook.js                  ← REPLACE (now attaches PDFs to emails)
│   └── validate-unlock.js          ← REPLACE (minor cleanup)
└── public/
    ├── TheTravelLabLogo.svg        ← ADD (top-nav logo)
    ├── TTLAC442Apps.svg            ← ADD (footer logo)
    └── pdfs/
        ├── LittleBuilder_FINAL.pdf       ← ADD
        ├── AdventureExplorer_FINAL.pdf   ← ADD
        └── PrincipalArchitect_FINAL.pdf  ← ADD
```

> ⚠️ If your repo already has a `pdfs/` folder somewhere else, move it to `/public/pdfs/`. The webhook reads from `process.cwd()/public/pdfs/`.

## 🔑 Vercel Environment Variables

Add/check these in **Vercel → Project → Settings → Environment Variables**:

| Variable | Value | Where to get |
|---|---|---|
| `STRIPE_SECRET_KEY` | `sk_test_...` (use TEST first, swap to `sk_live_...` for launch) | Stripe → Developers → API Keys |
| `STRIPE_WEBHOOK_SECRET` | `whsec_...` | Stripe → Developers → Webhooks → your endpoint |
| `RESEND_API_KEY` | `re_...` | Resend → API Keys |
| `FROM_EMAIL` | `The Travel Lab Academy <hello@thetravellabacademy.co.uk>` | After Resend domain verified |
| `SITE_URL` | `https://thetravellabacademy.co.uk` | (or whichever is your primary) |

If you have Vercel KV connected, `KV_REST_API_URL` and `KV_REST_API_TOKEN` get injected automatically — no action needed.

## 🪝 Stripe Webhook

In **Stripe → Developers → Webhooks**:
- Endpoint URL: `https://thetravellabacademy.co.uk/api/webhook`
- Events to send: `checkout.session.completed` (just this one for now)
- Copy the **Signing secret** (`whsec_...`) into Vercel env var `STRIPE_WEBHOOK_SECRET`

## 📦 NPM dependencies

Your repo's `package.json` should have these in `dependencies`:
- `stripe`
- `resend`
- `@vercel/kv` (optional, only if using Vercel KV)

If any are missing, run `npm install stripe resend` and commit the updated `package.json` + `package-lock.json`.

## 🧪 Test purchase flow

1. Switch Stripe to **Test mode** (toggle top-right of Stripe dashboard)
2. Use Vercel `STRIPE_SECRET_KEY` = test secret key
3. Update Stripe webhook to listen in test mode too
4. Buy any product on your site
5. Use Stripe's test card: `4242 4242 4242 4242`, any future date, any CVC, any postcode
6. Check:
   - ✅ Stripe shows the test payment as Succeeded
   - ✅ Vercel function logs show "Unlock key created"
   - ✅ Your inbox receives a welcome email WITH the PDF attached
   - ✅ The unlock link in the email opens the mission

Once that works, flip to Live mode (swap test keys for live keys, update webhook).
